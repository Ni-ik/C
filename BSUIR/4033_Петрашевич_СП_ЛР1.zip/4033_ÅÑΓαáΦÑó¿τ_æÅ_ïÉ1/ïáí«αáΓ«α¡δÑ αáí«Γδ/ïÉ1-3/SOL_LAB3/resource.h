//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sp_pr3.rc
//
#define IDI_ICON1                       101
#define IDC_CURSOR1                     102
#define IDR_MENU1                       103
#define IDR_ACCELERATOR1                104
#define IDM_FILE_NEW                    40012
#define IDM_FILE_OPEN                   40013
#define IDM_FILE_EXIT                   40014
#define IDM_EDIT_SELECT                 40015
#define IDM_EDIT_CUT                    40016
#define IDM_EDIT_COPY                   40017
#define IDM_EDIT_PASTE                  40018
#define IDM_HELP                        40019
#define IDM_HELP_CONTENTS               40020
#define IDM_HELP_ABOUT                  40021
#define IDM_EDIT_                       40026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40031
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

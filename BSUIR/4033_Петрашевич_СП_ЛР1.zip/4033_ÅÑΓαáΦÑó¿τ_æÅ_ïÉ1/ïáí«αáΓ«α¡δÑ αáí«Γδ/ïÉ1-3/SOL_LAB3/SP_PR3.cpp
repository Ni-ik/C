#include <windows.h>
#include <tchar.h>
#include "SP_PR3.h"
#include "resource.h"

#define ID_STATUS 200
LPWSTR lpszMsgSpace;
TCHAR szHint[1000];

HWND InitInstance(HINSTANCE hInstance, int nCmdShow){
	WNDCLASSEX wc;
	HWND hWnd;
      memset(&wc,0,sizeof(WNDCLASSEX));
      wc.cbSize=sizeof(WNDCLASSEX);
      wc.lpszClassName = lpszClassName;
      wc.lpfnWndProc = Pr2_WndProc;
      wc.style = CS_VREDRAW | CS_HREDRAW;
      wc.hInstance = hInstance;
      wc.hIcon = LoadIcon( hInstance, MAKEINTRESOURCE(IDI_ICON1));
      wc.hCursor = LoadCursor( hInstance, MAKEINTRESOURCE(IDC_CURSOR1));
 	  wc.hbrBackground = (HBRUSH) (COLOR_WINDOW+0 );
      wc.lpszMenuName = NULL;
      wc.cbClsExtra = 0;
      wc.cbWndExtra = 0;
      if(!RegisterClassEx( &wc ))
          { MessageBox(NULL,TEXT("������ ����������� ������ ����!"), TEXT("������"),MB_OK|MB_ICONERROR);
            return 0;
          }
	  hMainMenu=LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU1));
	  hWnd = CreateWindowEx( NULL, lpszClassName, lpszApplicationTitle,WS_OVERLAPPEDWINDOW,
		  100,100,1000,400,NULL,hMainMenu,hInstance,NULL);
      if(!hWnd)
          { MessageBox(NULL,TEXT("���� �� �������!"), TEXT("������"),MB_OK|MB_ICONERROR);
            return 0; 
          }
      ShowWindow( hWnd, nCmdShow );
      UpdateWindow(hWnd);
	  return hWnd;
}
int APIENTRY _tWinMain( HINSTANCE hInstance,HINSTANCE hPrevInstance, LPTSTR lpszCmdLine,  int nCmdShow )
{
   MSG msg;
   HACCEL accels;
   hMyInstance=hInstance;
   if(!(hMain=InitInstance(hInstance,nCmdShow)))
	   return 1;
   accels=LoadAccelerators(hInstance,MAKEINTRESOURCE(IDR_ACCELERATOR1));
   while( GetMessage( &msg, NULL, 0, 0 ) ) 
   {
	   if(!TranslateAccelerator(hMain,accels,&msg))
		DispatchMessage( &msg );
   }
   return msg.wParam;
}

void _setMenuItemStateByCommand(HMENU hParent, int id, int state)
{
	int sub;
	for(sub=0;;sub++){
		MENUITEMINFO mi;
		ZeroMemory(&mi,sizeof(mi));
		mi.cbSize=sizeof(mi);
		mi.fMask=MIIM_STATE|MIIM_SUBMENU|MIIM_ID;
		if(!GetMenuItemInfo(hParent,sub,true,&mi))
			break;
		if((!mi.hSubMenu)&&(mi.wID==id)){
			mi.fMask=MIIM_STATE;
			mi.fState=state;
			SetMenuItemInfo(hParent,sub,true,&mi);
		}
		else
			_setMenuItemStateByCommand(mi.hSubMenu, id, state);
	}
}

void setMenuItemStateByCommand(int id, int state){
	_setMenuItemStateByCommand(hMainMenu, id, state);
	DrawMenuBar(hMain);
}

void _GetMenuItemByCommand(HMENU hParent, int id, UINT *state, LPTSTR caption)
{
	int sub;
	for(sub=0;;sub++){
		MENUITEMINFO mi;
		TCHAR buf[1000];
		ZeroMemory(&mi,sizeof(mi));
		mi.cbSize=sizeof(mi);
		mi.fMask=MIIM_STATE|MIIM_SUBMENU|MIIM_ID|MIIM_STRING;
		mi.dwTypeData=buf;
		mi.cch=sizeof(buf)/sizeof(TCHAR);
		if(!GetMenuItemInfo(hParent,sub,true,&mi))
			break;
		if((!mi.hSubMenu)&&(mi.wID==id)){
			*state=mi.fState;
			if(caption)
				lstrcpy(caption,mi.dwTypeData);
			return;
		}
		else
			_GetMenuItemByCommand(mi.hSubMenu, id, state, caption);
	}
}

UINT GetMenuItemByCommand(int id, LPTSTR caption){
	UINT tmp;
	_GetMenuItemByCommand(hMainMenu, id, &tmp, caption);
	return tmp;
}

bool CreateMenuItem(HMENU hParent, LPTSTR name, UINT id, UINT state){
	MENUITEMINFO miNew;
	ZeroMemory(&miNew,sizeof(miNew));
	miNew.cbSize=sizeof(miNew);
	miNew.fMask=MIIM_DATA|MIIM_FTYPE|MIIM_ID|MIIM_STATE|MIIM_STRING;
	miNew.fType=MFT_STRING;
	miNew.fState=state;
	miNew.wID=id;
	miNew.dwTypeData=name;
	miNew.cch=lstrlen(name);
	return InsertMenuItem(hParent,0,true,&miNew);
}

void CmdNameByID(int id, LPTSTR buf){
	lstrcpy(buf,TEXT(""));
	GetMenuItemByCommand(id,buf);
}

LRESULT CALLBACK Pr2_WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam ){
	HDC hDC;
	PAINTSTRUCT ps;
	RECT cr,tr;
	switch(msg){
		case WM_DESTROY:
			MessageBox(NULL,lpszDestroyMessage, TEXT("WM_DESTROY"),MB_OK);
			PostQuitMessage(0);
			break;
		case WM_LBUTTONDOWN:
			MessageBox(NULL,L"����", TEXT("CLICK"),MB_OK);
			break;
		case WM_RBUTTONDOWN:
			{	 //������� ����������� ����
				DWORD xyPos=GetMessagePos();
				int x=LOWORD(xyPos);
				int y=HIWORD(xyPos);
				HMENU hContextMenu=CreatePopupMenu();
				CreateMenuItem(hContextMenu,TEXT("��������"),IDM_EDIT_SELECT,
					GetMenuItemByCommand(IDM_EDIT_SELECT,NULL));
				CreateMenuItem(hContextMenu,TEXT("����������"),IDM_EDIT_COPY,
					GetMenuItemByCommand(IDM_EDIT_COPY,NULL));
				TrackPopupMenu(hContextMenu,TPM_TOPALIGN|TPM_LEFTALIGN|
					TPM_LEFTBUTTON,x,y,0,hMain,NULL);
				DestroyMenu(hContextMenu);
			}
		case WM_PAINT:
			hDC=BeginPaint(hMain,&ps);
			GetClientRect(hMain,&cr);
			EndPaint(hMain,&ps); 
			break;
		case WM_CREATE:
			{		//��������� ������� ��������
				HMENU hFileMenu=GetSubMenu(hMainMenu,0);
				CreateMenuItem(hFileMenu,TEXT("������� ��������"),IDM_FILE_CLOSE,
					MFS_ENABLED);
			}
			if(MessageBox(NULL,lpszCreateMessage,TEXT("WM_CREATE"),MB_OKCANCEL)==IDCANCEL)
				return -1;
			else
				return 0;
			break;
		case WM_COMMAND:
			{
				int cmd=LOWORD(wParam);
				TCHAR cmdName[1000], message[1000];
				CmdNameByID(cmd,cmdName);
				switch(cmd){
					case IDM_FILE_NEW:
						setMenuItemStateByCommand(IDM_EDIT_SELECT,MFS_ENABLED);
											
						break;
					case IDM_FILE_CLOSE:
						setMenuItemStateByCommand(IDM_EDIT_SELECT,MFS_GRAYED);
						setMenuItemStateByCommand(IDM_EDIT_CUT,MFS_GRAYED);
						setMenuItemStateByCommand(IDM_EDIT_COPY,MFS_GRAYED);
						setMenuItemStateByCommand(IDM_EDIT_PASTE,MFS_GRAYED);

						break;
					case IDM_EDIT_SELECT:
						setMenuItemStateByCommand(IDM_EDIT_COPY,MFS_ENABLED);
						break;
				}

				if(cmdName)
					wsprintf(message,TEXT("������� ������� \"%s\""),cmdName);
				else
					wsprintf(message,TEXT("������� � ��������������� %d �� �����������"),cmd);
				MessageBox(NULL,message,TEXT("���������� ��������� WM_COMMAND"),MB_OK);
			}
			break;

		case WM_MENUSELECT:
			{
				HDC hdc1;

lpszMsgSpace=TEXT("____________________________");

TCHAR Buf[300];

HINSTANCE hInst;

hInst=(HINSTANCE)GetWindowLong(hWnd,GWL_HINSTANCE);

int size;

size=LoadString(hInst,LOWORD(wParam),Buf,300);

hdc1= GetDC(hWnd);

RECT rc;

GetClientRect (hWnd,&rc);

TextOut(hdc1, rc.left+10,rc.bottom-30,	lpszMsgSpace,lstrlen(lpszMsgSpace));

TextOut(hdc1,rc.left+10,rc.bottom-30,Buf,lstrlen(Buf));

ReleaseDC(hWnd, hdc1);

break;

}
			/*}InvalidateRect(hMain,NULL,true);
			if((lParam!=-1)&&(HIWORD(wParam)!=0xFFFF))
				LoadString(hMyInstance,LOWORD(wParam),szHint,sizeof(szHint)/sizeof(TCHAR));
			
			else
				lstrcpy(szHint,TEXT(""));
			break;	   */

		default:
			return( DefWindowProc( hWnd, msg, wParam, lParam ));
	}
	return 0;
}
